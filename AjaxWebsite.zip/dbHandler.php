<?php
	$databaseName = "robccromer_database";
	$userName = "robcromer";
	$password = "pKu9?t09";
	$serverLink = "50.62.209.8:3306";
	$connection = mysqli_connect($serverLink, $userName, $password, $databaseName);
?>